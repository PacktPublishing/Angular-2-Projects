#Angular 2 Projects - Weather

## Getting started

To get set up, run the following commands:

```
npm install
bower install
typings install
```

To build and launch the application, run the `gulp dev` command.

## Credit

Images retrieved from Wikipedia at the following URLs:

https://commons.wikimedia.org/wiki/File:New_york_times_square-terabass.jpg
https://commons.wikimedia.org/wiki/File:Shibuya_Night_(HDR).jpg
https://commons.wikimedia.org/wiki/File:Sydney_opera_house_side_view.jpg
https://commons.wikimedia.org/wiki/File:Eiffel_tower_from_trocadero.jpg
https://commons.wikimedia.org/wiki/File:English_Bay,_Vancouver,_BC.jpg
https://commons.wikimedia.org/wiki/File:View_Towards_the_City_of_London_-_geograph.org.uk_-_1776263.jpg
https://commons.wikimedia.org/wiki/File:Akshardham_Delhi.jpg
https://commons.wikimedia.org/wiki/File:Clifton_Beachs.jpg
https://commons.wikimedia.org/wiki/File:Bogotaview.jpg