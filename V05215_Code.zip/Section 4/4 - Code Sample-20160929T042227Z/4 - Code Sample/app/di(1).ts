import {OpaqueToken} from "@angular/core";

export const IoToken = new OpaqueToken("io");