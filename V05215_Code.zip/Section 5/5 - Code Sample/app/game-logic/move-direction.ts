export enum MoveDirection {
    None = 0,
    Forward = 1,
    Backward = 2,
    Both = 3
}