export enum Side {
    Dark,
    Light
}